package com.upgrad.FoodOrderingApp.api.controller;

public class UserController {
}
